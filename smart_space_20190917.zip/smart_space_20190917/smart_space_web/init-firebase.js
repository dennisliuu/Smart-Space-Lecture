var firebaseConfig = {
    apiKey: "AIzaSyBoIwMguLhw29YNvdYU9BGuPf9l9ozbm1Q",
    authDomain: "smart-space-1430e.firebaseapp.com",
    databaseURL: "https://smart-space-1430e.firebaseio.com",
    projectId: "smart-space-1430e",
    storageBucket: "smart-space-1430e.appspot.com",
    messagingSenderId: "1021965071886",
    appId: "1:1021965071886:web:092ad4cf01e2249089ee5f"
};
firebase.initializeApp(firebaseConfig);